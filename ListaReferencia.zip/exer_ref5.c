#include <stdio.h>
#include <locale.h>

/* Exerc�cio 5
exemplos:           [5, 9, 8]
                M = [1, 7, 4] --> maior: 9
                    [3, 2, 6]
entrada:        elementos de uma matriz 3x3
processamento:  leia a matriz em uma fun��o e encontre o maior elemento
saida:          maior elemento da matriz
*/

float maiorElemento(float m1[][3], int l) {
    float maior;
    maior = m1[0][0];
    for(int i=0; i<l; i++) {
        for(int j=0; j<3; j++) {
            if(m1[i][j]>maior) {
                maior = m1[i][j];
            }
        }
    }
    return maior;
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    float matriz3por3[3][3];
    int linhas;
    linhas = 3;
    float maiorElem;

    printf("Insira os valores dos elementos da matriz 3x3:\n");
    for(int i=0; i<3; i++) {
        for(int j=0; j<3; j++) {
            printf("Linha %d, coluna %d: ", i+1, j+1);
            scanf("%f", &matriz3por3[i][j]);
        }
    }

    maiorElem = maiorElemento(matriz3por3, linhas);

    printf("O maior elementos da matriz �: %g", maiorElem);

    return 0;
}
