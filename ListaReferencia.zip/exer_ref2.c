#include <stdio.h>
#include <locale.h>

/* Exerc�cio 2
exemplos:       v1 = [1,3,5]; v2 = [2,4,6] --> v3 = [1,2,3,4,5,6]
                v1 = [3,5,7]; v2 = [4,6,8] --> v3 = [3,4,5,6,7,8]
entrada:        tamanho dos dois vetores e seus elementos
processamento:  intercalar os elementos de ambos os vetores no terceiro vetor em uma fun��o
saida:          valores do terceiro vetor
*/

void intercala (int v1[], int v2[], int v3[], int dimensao) {
    int d;
    d = dimensao*2;
    v3[d];
    int j = 0;

    for(int i=0; i<d && j<dimensao; i+=2) {
        v3[i] = v1[j];
        v3[i+1] = v2[j];
        j++;
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    int n;

    printf("Insira o tamanho dos vetores 1 e 2: ");
    scanf("%d", &n);

    int num;
    num = n*2;

    int vetor1[n], vetor2[n], vetor3[num];
    printf("Insira os valores dos elementos dos vetores:\n");
    for(int i=0; i<n; i++) {
        printf("Vetor 1, valor %d: ", i+1);
        scanf("%d", &vetor1[i]);
    }
    for(int i=0; i<n; i++) {
        printf("Vetor 2, valor %d: ", i+1);
        scanf("%d", &vetor2[i]);
    }

    intercala(vetor1, vetor2, vetor3, n);

    printf("Os valores do vetor 3 s�o: [");
    for(int i=0; i<num; i++) {
        printf("%d ", vetor3[i]);
    }
    printf("]");

    return 0;
}
