#include <stdio.h>
#include <locale.h>

/* Exerc�cio 4
exemplos:       V1 = [1, 2, 3, 4, 5], V2 = [1, 2, 3, 4, 5] --> os vetores s�o iguais
                V1 = [4, 3, 2, 5, 1], V2 = [5, 4, 1, 3, 2] --> os vetores t�m os mesmos elementos em ordem diferente
                V1 = [1, 2, 3, 4, 5, 6], V2 = [1, 2, 3, 4, 5] --> o primeiro vetor tem, pelo menos, um valor que n�o h� no segundo
entrada:        tamanho e elementos de dois vetores
processamento:  ler ambos os vetores e analisar, atrav�s de fun��o, se eles s�o iguais, tem os mesmos elementos em ordem diferente ou tem pelo menos um elemento diferente
saida:
*/

int comparaVetor(int v1[], int t1, int v2[], int t2) {
    int comparaIgual = 0, comparaDiff = 0, fatorDiff = -1;

    if(t1 == t2) {
        for(int i=0; i<t1; i++) {
            if(v1[i]==v2[i]) {
                comparaIgual+=1;
            }
        }
        if(comparaIgual == t1) {
            return 1;
        }
        else {
            for(int i=0; i<t1; i++) {
                for(int j=0; j<t1; j++) {
                    if(v1[i] == v2[j]) {
                        if(fatorDiff != i) {
                            comparaDiff+=1;
                            fatorDiff = i;
                        }
                    }
                }
            }
            if(comparaDiff == t1) {
                return 2;
            }
            else {
                return 3;
            }
        }
    }
    else if(t1 > t2){
        return 3;
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    int tam1, tam2;

    printf("Insira o tamanho do vetor 1: ");
    scanf("%d", &tam1);
    printf("Insira o tamanho do vetor 2: ");
    scanf("%d", &tam2);

    int vetTam1[tam1], vetTam2[tam2];

    for(int i=0; i<tam1; i++) {
        printf("Insira o elemento do vetor 1 em posi��o %d: ", i+1);
        scanf("%d", &vetTam1[i]);
    }
    for(int i=0; i<tam2; i++) {
        printf("Insira o elemento do vetor 2 em posi��o %d: ", i+1);
        scanf("%d", &vetTam2[i]);
    }

    if(comparaVetor(vetTam1, tam1, vetTam2, tam2)==1) {
        printf("Os vetores s�o iguais");
    }
    else if(comparaVetor(vetTam1, tam1, vetTam2, tam2)==2) {
        printf("Os vetores tem os mesmos elementos, mas em ordem diferente");
    }
    else if(comparaVetor(vetTam1, tam1, vetTam2, tam2)==3) {
        printf("H� pelo menos um elemento no primeiro que n�o h� no segundo");
    }

    return 0;
}

