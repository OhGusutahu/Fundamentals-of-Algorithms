#include <stdio.h>
#include <locale.h>

/* Exerc�cio 1
exemplos:       n = 3; vetor = [2,3,4] --> h� 2 elementos pares
                n = 5; vetor = [5,8,7,6,9] --> h� 2 elementos pares
entrada:        quantas posi��es o vetor ter� atrav�s de 'n' e os elementos do vetor
processamento:  calcular quantos desses elementos s�o pares em uma fun��o
saida:          quantidade de elementos pares no vetor
*/

int pares(int vetor[], int n) {
    int par = 0;
    for(int i=0; i<n; i++) {
        if(vetor[i]%2 == 0) {
            par++;
        }
    }
    return par;
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    int N, qtdPar;

    printf("Insira quantas posi��es o vetor ter�: ");
    scanf("%d", &N);

    int vetorN[N];
    printf("Insira os valores dos elementos do vetor:\n");
    for(int i = 0; i<N; i++) {
        printf("valor %d: ", i+1);
        scanf("%d", &vetorN[i]);
    }

    qtdPar = pares(vetorN,N);

    printf("H� %d n�meros pares no vetor", qtdPar);

    return 0;
}
