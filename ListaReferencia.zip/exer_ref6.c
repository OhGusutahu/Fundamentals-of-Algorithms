#include <stdio.h>
#include <locale.h>

/* Exerc�cio 6
exemplos:           [ 5,  6,  4,  3,  2]
                    [ 9, 10, 12,  1,  7]
                M = [13,  0, 18,  5,  3] --> V = [5, 10, 18, 2, 14]
                    [16, 21, 25,  2, 19]
                    [ 1,  2, 35,  4, 14]
entrada:        valores dos elementos da matriz 5x5
processamento:  amarmazenar, atrav�s de uma fun��o, os elementos da diagonal principal da matriz no vetor
saida:          vetor com os elementos da diagonal da matriz
*/

void diagMatriz(float m1[][5], int l, float v1[], int p) {
        int i = 0;
        for(int j=0; j<l; j++) {
                v1[i] = m1[j][j];
                i++;
        }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    float matriz5por5[5][5];
    int tamLinha;
    tamLinha = 5;
    float vetorDiag[5];
    int posVet;
    posVet = 5;

    printf("Insira os valores dos elementos da matriz 5x5:\n");
    for(int i=0; i<5; i++) {
        for(int j=0; j<5; j++) {
            printf("Linha %d, coluna %d: ", i+1, j+1);
            scanf("%f", &matriz5por5[i][j]);
        }
    }

    diagMatriz(matriz5por5, tamLinha, vetorDiag, posVet);
    printf("O vetor da diagonal principal da matriz �: [");
    for(int i=0; i<5; i++) {
        printf("%g ", vetorDiag[i]);
    }
    printf("]");

    return 0;
}
