#include <stdio.h>
#include <locale.h>

/* Exerc�cio 3
exemplos:       V = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]   --> V = [1, 9, 8, 7, 6, 5, 4, 3, 2, 10]
                V = [20, 15, 6, 7, 2, 7, 9, 8, 4, 13] --> V = [2, 15, 6, 7, 20, 7, 9, 8, 4, 13]
entrada:        valores dos elementos do vetor
processamento:  encontra o valor maior e substitui com o primeiro em uma fun��o
saida:          vetor com os elementos trocados
*/

void trocaMaior (float vet[], int n) {
    float res = vet[0];

    for(int i=0; i<n; i++) {
        if(vet[i]<res) {
            res = vet[i];
        }
    }
    for(int i=0; i<n; i++) {
        if(vet[i]==res) {
            vet[i]=vet[0];
        }
    }
    vet[0]=res;

    for(int i=0; i<n; i++) {
        printf("%g ", vet[i]);
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    float vetor10Ele[10];
    int tam = 10;

    for(int i=0; i<10; i++) {
        printf("Insira o valor do elemento %d do vetor: ", i+1);
        scanf("%f", &vetor10Ele[i]);
    }

    printf("\n");
    printf("O vetor trocado �: [");
    trocaMaior(vetor10Ele, tam);
    printf("]");

    return 0;
}
