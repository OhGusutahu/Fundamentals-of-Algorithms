#include <stdio.h>

/* Exercicio 3
exemplo:        4, 5 --> 1024
                3, 3 --> 27
entrada:        um numero e um expoente
processamento:  atrav�s de uma fun��o, multiplica o numero por si mesmo 'expoente' vezes
saida:          o resultado da potencia
*/

int potencia(int x, int y) {
    if(y == 1) {
        return x;
    }
    else {
        return x*potencia(x, y-1);
    }
}

int main() {

    int num, poten, res;
    printf("Insira um numero: ");
    scanf("%d", &num);
    printf("Insira um expoente: ");
    scanf("%d", &poten);

    res = potencia(num, poten);

    printf("\n%d elevado a %d = %d", num, poten, res);

    return 0;
}

