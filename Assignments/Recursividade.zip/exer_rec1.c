#include <stdio.h>

/* Exercicio 1
exemplo:        4 --> 4; 5 --> 5; 6 --> 6; 2 --> 2; -1 --> [end];
                3 --> 3; 8 --> 8; -3 --> [end];
entrada:        um numero
processamento:  se o numero for negativo, a fun��o para; caso contr�rio, imprime o numero e faz uma chamada recursiva a si mesma
saida:          o numero inserido (caso n�o negativo)
*/

int positivo() {
    int n;
    printf("Insira um numero: ");
    scanf("%d", &n);

    if(n<0) {
        return 0;
    }
    else {
        printf("%d\n", n);
        return positivo();
    }
}

int main() {
    positivo();

    return 0;
}
