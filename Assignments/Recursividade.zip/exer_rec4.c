#include <stdio.h>

/* Exercicio 4
exemplo:        [2, 16] k=3 --> 2, 5, 8, 11, 14
                [5, 5] k=1 --> 5
                [8, 2] k=2 --> [end]
entrada:        inicio (i) e fim (j) de um intervalo [i,j] e o incremento (k)
processamento:  em uma fun��o, imprime a s�rie de valores do intervalo [i,j] com o incremento k
saida:          os valores do intervalo com o incremento k
*/

int ImprimeSerie(int i, int j, int k) {
    while(i<j) {
        printf("%d ", i);
        return ImprimeSerie(i+k,j,k);
    }
    if(i == j) {
        printf("%d", i);
    }
}

int main() {

    int inicio, fim, incremento;

    printf("Insira os valores do intervalo:\n");
    printf("Inicio: ");
    scanf("%d", &inicio);
    printf("Fim: ");
    scanf("%d", &fim);
    printf("Insira o incremento: ");
    scanf("%d", &incremento);

    ImprimeSerie(inicio, fim, incremento);

    return 0;
}

